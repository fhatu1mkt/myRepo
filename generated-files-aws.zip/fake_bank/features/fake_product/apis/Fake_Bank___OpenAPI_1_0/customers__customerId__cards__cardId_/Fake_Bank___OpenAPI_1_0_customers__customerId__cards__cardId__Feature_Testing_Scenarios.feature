
@Fake_Bank___OpenAPI_1_0_customers__customerId__cards__cardId__Feature_Testing_Scenarios
@Rest_Api_Application
@allure.label.epic:This_is_a_sample_Bank_based_on_the_OpenAPI_3_0_specification___It_is_loosely_based_on__https___github_com_bian_official__https___github_com_bian_official___The_intention_of_this_API_is_to_teach_the_fundamentals_of_typical_APIs_in_a_bank___Some_useful_links_____Nacha___A_payments_governance_org_in_US__https___www_nacha_org_content_afinis_api_catalog_Epic_Functional_Testing
@allure.label.parentSuite:This_is_a_sample_Bank_based_on_the_OpenAPI_3_0_specification___It_is_loosely_based_on__https___github_com_bian_official__https___github_com_bian_official___The_intention_of_this_API_is_to_teach_the_fundamentals_of_typical_APIs_in_a_bank___Some_useful_links_____Nacha___A_payments_governance_org_in_US__https___www_nacha_org_content_afinis_api_catalog_Epic_Functional_Testing
@allure.label.suite:Fake_Bank___OpenAPI_1_0_customers__customerId__cards__cardId__Feature_Testing_Scenarios
Feature: Fake Bank   OpenAPI 1 0 customers  customerId  cards  cardId  Feature Testing Scenarios
    
@200_Successful_Operation_GET_Customers_CustomerId_Cards_CardId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Cards_CardId_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_GET_Customers_CustomerId_Cards_CardId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Cards_CardId_Testing_Scenario
    Scenario Outline: 200 Successful Operation GET Customers CustomerId Cards CardId Fake Bank OpenAPI 1 0 Customers CustomerId Cards CardId Testing Scenario
        Given I have started "200 Successful Operation GET Customers CustomerId Cards CardId Fake Bank OpenAPI 1 0 Customers CustomerId Cards CardId Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "GETCustomersCustomerIdCardsCardId" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers_CustomerId_Cards_CardId/200_GET_Customers_CustomerId_Cards_CardId_test_data.csv" loaded

        When I have called "GETCustomersCustomerIdCardsCardId" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|
			|GETCustomersCustomerIdCardsCardId|/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers_CustomerId_Cards_CardId/rest-service-config.csv|

        Then "GETCustomersCustomerIdCardsCardId" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "GETCustomersCustomerIdCardsCardId" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers_CustomerId_Cards_CardId/200_GET_Customers_CustomerId_Cards_CardId_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers_CustomerId_Cards_CardId/200_GET_Customers_CustomerId_Cards_CardId_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|GET_Customers_CustomerId_Cards_CardId_200_Successful_Operation_Test_Case| |

    
@200_Successful_Operation_PUT_Customers_CustomerId_Cards_CardId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Cards_CardId_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_PUT_Customers_CustomerId_Cards_CardId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Cards_CardId_Testing_Scenario
    Scenario Outline: 200 Successful Operation PUT Customers CustomerId Cards CardId Fake Bank OpenAPI 1 0 Customers CustomerId Cards CardId Testing Scenario
        Given I have started "200 Successful Operation PUT Customers CustomerId Cards CardId Fake Bank OpenAPI 1 0 Customers CustomerId Cards CardId Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "PUTCustomersCustomerIdCardsCardId" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers_CustomerId_Cards_CardId/200_PUT_Customers_CustomerId_Cards_CardId_test_data.csv" loaded

        When I have called "PUTCustomersCustomerIdCardsCardId" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|Request_Sample_and_Base_Data|TestData_DataSource_Service_FieldMappings_FilePath|
			|PUTCustomersCustomerIdCardsCardId|/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers_CustomerId_Cards_CardId/rest-service-config.csv|/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers_CustomerId_Cards_CardId/PUT_Customers_CustomerId_Cards_CardId_request_sample.json|/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers_CustomerId_Cards_CardId/PUT_Customers_CustomerId_Cards_CardId_request_field_Mappings.csv|

        Then "PUTCustomersCustomerIdCardsCardId" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "PUTCustomersCustomerIdCardsCardId" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers_CustomerId_Cards_CardId/200_PUT_Customers_CustomerId_Cards_CardId_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers_CustomerId_Cards_CardId/200_PUT_Customers_CustomerId_Cards_CardId_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|PUT_Customers_CustomerId_Cards_CardId_200_Successful_Operation_Test_Case| |

    
@200_Successful_Operation_DELETE_Customers_CustomerId_Cards_CardId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Cards_CardId_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_DELETE_Customers_CustomerId_Cards_CardId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Cards_CardId_Testing_Scenario
    Scenario Outline: 200 Successful Operation DELETE Customers CustomerId Cards CardId Fake Bank OpenAPI 1 0 Customers CustomerId Cards CardId Testing Scenario
        Given I have started "200 Successful Operation DELETE Customers CustomerId Cards CardId Fake Bank OpenAPI 1 0 Customers CustomerId Cards CardId Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "DELETECustomersCustomerIdCardsCardId" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/DELETE_Customers_CustomerId_Cards_CardId/200_DELETE_Customers_CustomerId_Cards_CardId_test_data.csv" loaded

        When I have called "DELETECustomersCustomerIdCardsCardId" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|
			|DELETECustomersCustomerIdCardsCardId|/fake_product/apis/Fake_Bank___OpenAPI_1_0/DELETE_Customers_CustomerId_Cards_CardId/rest-service-config.csv|

        Then "DELETECustomersCustomerIdCardsCardId" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "DELETECustomersCustomerIdCardsCardId" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/DELETE_Customers_CustomerId_Cards_CardId/200_DELETE_Customers_CustomerId_Cards_CardId_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/DELETE_Customers_CustomerId_Cards_CardId/200_DELETE_Customers_CustomerId_Cards_CardId_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|DELETE_Customers_CustomerId_Cards_CardId_200_Successful_Operation_Test_Case| |

