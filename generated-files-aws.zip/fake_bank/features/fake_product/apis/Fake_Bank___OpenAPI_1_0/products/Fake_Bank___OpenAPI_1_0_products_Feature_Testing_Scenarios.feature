
@Fake_Bank___OpenAPI_1_0_products_Feature_Testing_Scenarios
@Rest_Api_Application
@allure.label.epic:This_is_a_sample_Bank_based_on_the_OpenAPI_3_0_specification___It_is_loosely_based_on__https___github_com_bian_official__https___github_com_bian_official___The_intention_of_this_API_is_to_teach_the_fundamentals_of_typical_APIs_in_a_bank___Some_useful_links_____Nacha___A_payments_governance_org_in_US__https___www_nacha_org_content_afinis_api_catalog_Epic_Functional_Testing
@allure.label.parentSuite:This_is_a_sample_Bank_based_on_the_OpenAPI_3_0_specification___It_is_loosely_based_on__https___github_com_bian_official__https___github_com_bian_official___The_intention_of_this_API_is_to_teach_the_fundamentals_of_typical_APIs_in_a_bank___Some_useful_links_____Nacha___A_payments_governance_org_in_US__https___www_nacha_org_content_afinis_api_catalog_Epic_Functional_Testing
@allure.label.suite:Fake_Bank___OpenAPI_1_0_products_Feature_Testing_Scenarios
Feature: Fake Bank   OpenAPI 1 0 products Feature Testing Scenarios
    
@200_Successful_Operation_POST_Products_Fake_Bank_OpenAPI_1_0_Products_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_POST_Products_Fake_Bank_OpenAPI_1_0_Products_Testing_Scenario
    Scenario Outline: 200 Successful Operation POST Products Fake Bank OpenAPI 1 0 Products Testing Scenario
        Given I have started "200 Successful Operation POST Products Fake Bank OpenAPI 1 0 Products Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "POSTProducts" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Products/200_POST_Products_test_data.csv" loaded

        When I have called "POSTProducts" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|Request_Sample_and_Base_Data|TestData_DataSource_Service_FieldMappings_FilePath|
			|POSTProducts|/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Products/rest-service-config.csv|/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Products/POST_Products_request_sample.json|/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Products/POST_Products_request_field_Mappings.csv|

        Then "POSTProducts" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "POSTProducts" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Products/200_POST_Products_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Products/200_POST_Products_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|POST_Products_200_Successful_Operation_Test_Case| |

    
@200_Successful_Operation_GET_Products_Fake_Bank_OpenAPI_1_0_Products_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_GET_Products_Fake_Bank_OpenAPI_1_0_Products_Testing_Scenario
    Scenario Outline: 200 Successful Operation GET Products Fake Bank OpenAPI 1 0 Products Testing Scenario
        Given I have started "200 Successful Operation GET Products Fake Bank OpenAPI 1 0 Products Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "GETProducts" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Products/200_GET_Products_test_data.csv" loaded

        When I have called "GETProducts" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|service_contextPath_param_field_mappings_file_path|
			|GETProducts|/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Products/rest-service-config.csv|/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Products/GET_Products_context_path_Value_mappings.csv|

        Then "GETProducts" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "GETProducts" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Products/200_GET_Products_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Products/200_GET_Products_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|GET_Products_200_Successful_Operation_Test_Case| |

    
@200_Successful_Operation_PUT_Products_Fake_Bank_OpenAPI_1_0_Products_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_PUT_Products_Fake_Bank_OpenAPI_1_0_Products_Testing_Scenario
    Scenario Outline: 200 Successful Operation PUT Products Fake Bank OpenAPI 1 0 Products Testing Scenario
        Given I have started "200 Successful Operation PUT Products Fake Bank OpenAPI 1 0 Products Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "PUTProducts" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Products/200_PUT_Products_test_data.csv" loaded

        When I have called "PUTProducts" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|Request_Sample_and_Base_Data|TestData_DataSource_Service_FieldMappings_FilePath|
			|PUTProducts|/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Products/rest-service-config.csv|/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Products/PUT_Products_request_sample.json|/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Products/PUT_Products_request_field_Mappings.csv|

        Then "PUTProducts" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "PUTProducts" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Products/200_PUT_Products_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Products/200_PUT_Products_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|PUT_Products_200_Successful_Operation_Test_Case| |

