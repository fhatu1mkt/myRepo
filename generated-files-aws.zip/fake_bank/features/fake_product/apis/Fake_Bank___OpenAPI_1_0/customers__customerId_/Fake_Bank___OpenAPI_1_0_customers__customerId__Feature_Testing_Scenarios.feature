
@Fake_Bank___OpenAPI_1_0_customers__customerId__Feature_Testing_Scenarios
@Rest_Api_Application
@allure.label.epic:This_is_a_sample_Bank_based_on_the_OpenAPI_3_0_specification___It_is_loosely_based_on__https___github_com_bian_official__https___github_com_bian_official___The_intention_of_this_API_is_to_teach_the_fundamentals_of_typical_APIs_in_a_bank___Some_useful_links_____Nacha___A_payments_governance_org_in_US__https___www_nacha_org_content_afinis_api_catalog_Epic_Functional_Testing
@allure.label.parentSuite:This_is_a_sample_Bank_based_on_the_OpenAPI_3_0_specification___It_is_loosely_based_on__https___github_com_bian_official__https___github_com_bian_official___The_intention_of_this_API_is_to_teach_the_fundamentals_of_typical_APIs_in_a_bank___Some_useful_links_____Nacha___A_payments_governance_org_in_US__https___www_nacha_org_content_afinis_api_catalog_Epic_Functional_Testing
@allure.label.suite:Fake_Bank___OpenAPI_1_0_customers__customerId__Feature_Testing_Scenarios
Feature: Fake Bank   OpenAPI 1 0 customers  customerId  Feature Testing Scenarios
    
@200_Successful_Operation_POST_Customers_CustomerId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_POST_Customers_CustomerId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Testing_Scenario
    Scenario Outline: 200 Successful Operation POST Customers CustomerId Fake Bank OpenAPI 1 0 Customers CustomerId Testing Scenario
        Given I have started "200 Successful Operation POST Customers CustomerId Fake Bank OpenAPI 1 0 Customers CustomerId Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "POSTCustomersCustomerId" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Customers_CustomerId/200_POST_Customers_CustomerId_test_data.csv" loaded

        When I have called "POSTCustomersCustomerId" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|
			|POSTCustomersCustomerId|/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Customers_CustomerId/rest-service-config.csv|

        Then "POSTCustomersCustomerId" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "POSTCustomersCustomerId" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Customers_CustomerId/200_POST_Customers_CustomerId_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Customers_CustomerId/200_POST_Customers_CustomerId_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|POST_Customers_CustomerId_200_Successful_Operation_Test_Case| |

    
@200_Successful_Operation_GET_Customers_CustomerId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_GET_Customers_CustomerId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Testing_Scenario
    Scenario Outline: 200 Successful Operation GET Customers CustomerId Fake Bank OpenAPI 1 0 Customers CustomerId Testing Scenario
        Given I have started "200 Successful Operation GET Customers CustomerId Fake Bank OpenAPI 1 0 Customers CustomerId Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "GETCustomersCustomerId" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers_CustomerId/200_GET_Customers_CustomerId_test_data.csv" loaded

        When I have called "GETCustomersCustomerId" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|
			|GETCustomersCustomerId|/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers_CustomerId/rest-service-config.csv|

        Then "GETCustomersCustomerId" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "GETCustomersCustomerId" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers_CustomerId/200_GET_Customers_CustomerId_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers_CustomerId/200_GET_Customers_CustomerId_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|GET_Customers_CustomerId_200_Successful_Operation_Test_Case| |

    
@200_Successful_Operation_DELETE_Customers_CustomerId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_DELETE_Customers_CustomerId_Fake_Bank_OpenAPI_1_0_Customers_CustomerId_Testing_Scenario
    Scenario Outline: 200 Successful Operation DELETE Customers CustomerId Fake Bank OpenAPI 1 0 Customers CustomerId Testing Scenario
        Given I have started "200 Successful Operation DELETE Customers CustomerId Fake Bank OpenAPI 1 0 Customers CustomerId Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "DELETECustomersCustomerId" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/DELETE_Customers_CustomerId/200_DELETE_Customers_CustomerId_test_data.csv" loaded

        When I have called "DELETECustomersCustomerId" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|
			|DELETECustomersCustomerId|/fake_product/apis/Fake_Bank___OpenAPI_1_0/DELETE_Customers_CustomerId/rest-service-config.csv|

        Then "DELETECustomersCustomerId" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "DELETECustomersCustomerId" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/DELETE_Customers_CustomerId/200_DELETE_Customers_CustomerId_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/DELETE_Customers_CustomerId/200_DELETE_Customers_CustomerId_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|DELETE_Customers_CustomerId_200_Successful_Operation_Test_Case| |

