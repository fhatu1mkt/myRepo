
@Fake_Bank___OpenAPI_1_0_customers_Feature_Testing_Scenarios
@Rest_Api_Application
@allure.label.epic:This_is_a_sample_Bank_based_on_the_OpenAPI_3_0_specification___It_is_loosely_based_on__https___github_com_bian_official__https___github_com_bian_official___The_intention_of_this_API_is_to_teach_the_fundamentals_of_typical_APIs_in_a_bank___Some_useful_links_____Nacha___A_payments_governance_org_in_US__https___www_nacha_org_content_afinis_api_catalog_Epic_Functional_Testing
@allure.label.parentSuite:This_is_a_sample_Bank_based_on_the_OpenAPI_3_0_specification___It_is_loosely_based_on__https___github_com_bian_official__https___github_com_bian_official___The_intention_of_this_API_is_to_teach_the_fundamentals_of_typical_APIs_in_a_bank___Some_useful_links_____Nacha___A_payments_governance_org_in_US__https___www_nacha_org_content_afinis_api_catalog_Epic_Functional_Testing
@allure.label.suite:Fake_Bank___OpenAPI_1_0_customers_Feature_Testing_Scenarios
Feature: Fake Bank   OpenAPI 1 0 customers Feature Testing Scenarios
    
@200_Successful_Operation_POST_Customers_Fake_Bank_OpenAPI_1_0_Customers_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_POST_Customers_Fake_Bank_OpenAPI_1_0_Customers_Testing_Scenario
    Scenario Outline: 200 Successful Operation POST Customers Fake Bank OpenAPI 1 0 Customers Testing Scenario
        Given I have started "200 Successful Operation POST Customers Fake Bank OpenAPI 1 0 Customers Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "POSTCustomers" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Customers/200_POST_Customers_test_data.csv" loaded

        When I have called "POSTCustomers" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|Request_Sample_and_Base_Data|TestData_DataSource_Service_FieldMappings_FilePath|
			|POSTCustomers|/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Customers/rest-service-config.csv|/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Customers/POST_Customers_request_sample.json|/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Customers/POST_Customers_request_field_Mappings.csv|

        Then "POSTCustomers" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "POSTCustomers" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Customers/200_POST_Customers_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/POST_Customers/200_POST_Customers_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|POST_Customers_200_Successful_Operation_Test_Case| |

    
@200_Successful_Operation_GET_Customers_Fake_Bank_OpenAPI_1_0_Customers_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_GET_Customers_Fake_Bank_OpenAPI_1_0_Customers_Testing_Scenario
    Scenario Outline: 200 Successful Operation GET Customers Fake Bank OpenAPI 1 0 Customers Testing Scenario
        Given I have started "200 Successful Operation GET Customers Fake Bank OpenAPI 1 0 Customers Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "GETCustomers" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers/200_GET_Customers_test_data.csv" loaded

        When I have called "GETCustomers" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|service_contextPath_param_field_mappings_file_path|
			|GETCustomers|/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers/rest-service-config.csv|/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers/GET_Customers_context_path_Value_mappings.csv|

        Then "GETCustomers" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "GETCustomers" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers/200_GET_Customers_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/GET_Customers/200_GET_Customers_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|GET_Customers_200_Successful_Operation_Test_Case| |

    
@200_Successful_Operation_PUT_Customers_Fake_Bank_OpenAPI_1_0_Customers_Testing_Scenario
@allure.label.subSuite:200_Successful_Operation_PUT_Customers_Fake_Bank_OpenAPI_1_0_Customers_Testing_Scenario
    Scenario Outline: 200 Successful Operation PUT Customers Fake Bank OpenAPI 1 0 Customers Testing Scenario
        Given I have started "200 Successful Operation PUT Customers Fake Bank OpenAPI 1 0 Customers Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "PUTCustomers" from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers/200_PUT_Customers_test_data.csv" loaded

        When I have called "PUTCustomers" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|Request_Sample_and_Base_Data|TestData_DataSource_Service_FieldMappings_FilePath|
			|PUTCustomers|/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers/rest-service-config.csv|/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers/PUT_Customers_request_sample.json|/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers/PUT_Customers_request_field_Mappings.csv|

        Then "PUTCustomers" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "PUTCustomers" "json_response" should be returned as per expected results from "/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers/200_PUT_Customers_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "/fake_product/apis/Fake_Bank___OpenAPI_1_0/PUT_Customers/200_PUT_Customers_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|PUT_Customers_200_Successful_Operation_Test_Case| |

