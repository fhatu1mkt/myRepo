package runner.fake_bank.fake_product.apis.Fake_Bank___OpenAPI_1_0.customers__customerId_;

import io.cucumber.testng.CucumberOptions;
import runner.SingleExecutionTestingRunner;

@CucumberOptions(tags =
        "@Fake_Bank___OpenAPI_1_0_customers__customerId__Feature_Testing_Scenarios")
public class Fake_Bank___OpenAPI_1_0_customers__customerId__Feature_Testing_Scenarios_Testing_Runner extends SingleExecutionTestingRunner {}