package runner.nedbank.test.automation.master.card.apis.bidvest.Bidvest_Lounge_API.lounges_confirm;

import io.cucumber.testng.CucumberOptions;
import runner.SingleExecutionTestingRunner;

@CucumberOptions(tags =
        "@Bidvest_Lounge_API_lounges_confirm_Feature_Testing_Scenarios")
public class Bidvest_Lounge_API_lounges_confirm_Feature_Testing_Scenarios_Testing_Runner extends SingleExecutionTestingRunner {}