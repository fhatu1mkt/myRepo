
@Bidvest_Lounge_API_lounges_access_Feature_Testing_Scenarios
@Rest_Api_Application
@allure.label.epic:Bidvest_Lounge_access_request_Epic_Functional_Testing
@allure.label.parentSuite:Bidvest_Lounge_access_request_Epic_Functional_Testing
@allure.label.suite:Bidvest_Lounge_API_lounges_access_Feature_Testing_Scenarios
Feature: Bidvest Lounge API lounges access Feature Testing Scenarios
    
@200_OK._Request_Was_Successful_GET_Lounges_Access_Bidvest_Lounge_API_Lounges_Access_Testing_Scenario
@allure.label.subSuite:200_OK._Request_Was_Successful_GET_Lounges_Access_Bidvest_Lounge_API_Lounges_Access_Testing_Scenario
    Scenario Outline: 200 OK. Request Was Successful GET Lounges Access Bidvest Lounge API Lounges Access Testing Scenario
        Given I have started "200 OK. Request Was Successful GET Lounges Access Bidvest Lounge API Lounges Access Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "GETLoungesAccess" from "card\apis\bidvest\Bidvest_Lounge_API\GET_Lounges_Access\200_GET_Lounges_Access_test_data.csv" loaded

        When I have called "GETLoungesAccess" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|service_contextPath_param_field_mappings_file_path|
			|GETLoungesAccess|card\apis\bidvest\Bidvest_Lounge_API\GET_Lounges_Access\rest-service-config.csv|card\apis\bidvest\Bidvest_Lounge_API\GET_Lounges_Access\GET_Lounges_Access_context_path_Value_mappings.csv|

        Then "GETLoungesAccess" "status_code" "http_response" field or column should be populated with the value "eq" "200"

        Then data from "GETLoungesAccess" "json_response" should be returned as per expected results from "card\apis\bidvest\Bidvest_Lounge_API\GET_Lounges_Access\200_GET_Lounges_Access_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "card\apis\bidvest\Bidvest_Lounge_API\GET_Lounges_Access\200_GET_Lounges_Access_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|GET_Lounges_Access_200_OK__Request_Was_Successful_Test_Case| |

    
@Default_Error_Processing_Request._GET_Lounges_Access_Bidvest_Lounge_API_Lounges_Access_Testing_Scenario
@allure.label.subSuite:Default_Error_Processing_Request._GET_Lounges_Access_Bidvest_Lounge_API_Lounges_Access_Testing_Scenario
    Scenario Outline: Default Error Processing Request. GET Lounges Access Bidvest Lounge API Lounges Access Testing Scenario
        Given I have started "Default Error Processing Request. GET Lounges Access Bidvest Lounge API Lounges Access Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "GETLoungesAccess" from "card\apis\bidvest\Bidvest_Lounge_API\GET_Lounges_Access\Default_GET_Lounges_Access_test_data.csv" loaded

        When I have called "GETLoungesAccess" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|service_contextPath_param_field_mappings_file_path|
			|GETLoungesAccess|card\apis\bidvest\Bidvest_Lounge_API\GET_Lounges_Access\rest-service-config.csv|card\apis\bidvest\Bidvest_Lounge_API\GET_Lounges_Access\GET_Lounges_Access_context_path_Value_mappings.csv|

        Then "GETLoungesAccess" "status_code" "http_response" field or column should be populated with the value "eq" "default"

        Then data from "GETLoungesAccess" "json_response" should be returned as per expected results from "card\apis\bidvest\Bidvest_Lounge_API\GET_Lounges_Access\Default_GET_Lounges_Access_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "card\apis\bidvest\Bidvest_Lounge_API\GET_Lounges_Access\Default_GET_Lounges_Access_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|GET_Lounges_Access_Default_Error_Processing_Request__Test_Case| |

