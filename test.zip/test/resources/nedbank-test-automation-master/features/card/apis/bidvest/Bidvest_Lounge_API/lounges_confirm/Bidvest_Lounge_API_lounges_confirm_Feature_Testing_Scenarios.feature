
@Bidvest_Lounge_API_lounges_confirm_Feature_Testing_Scenarios
@Rest_Api_Application
@allure.label.epic:Bidvest_Lounge_access_request_Epic_Functional_Testing
@allure.label.parentSuite:Bidvest_Lounge_access_request_Epic_Functional_Testing
@allure.label.suite:Bidvest_Lounge_API_lounges_confirm_Feature_Testing_Scenarios
Feature: Bidvest Lounge API lounges confirm Feature Testing Scenarios
    
@201_Created._Confirmation_Was_Successful_POST_Lounges_Confirm_Bidvest_Lounge_API_Lounges_Confirm_Testing_Scenario
@allure.label.subSuite:201_Created._Confirmation_Was_Successful_POST_Lounges_Confirm_Bidvest_Lounge_API_Lounges_Confirm_Testing_Scenario
    Scenario Outline: 201 Created. Confirmation Was Successful POST Lounges Confirm Bidvest Lounge API Lounges Confirm Testing Scenario
        Given I have started "201 Created. Confirmation Was Successful POST Lounges Confirm Bidvest Lounge API Lounges Confirm Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "POSTLoungesConfirm" from "card\apis\bidvest\Bidvest_Lounge_API\POST_Lounges_Confirm\201_POST_Lounges_Confirm_test_data.csv" loaded

        When I have called "POSTLoungesConfirm" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|service_contextPath_param_field_mappings_file_path|
			|POSTLoungesConfirm|card\apis\bidvest\Bidvest_Lounge_API\POST_Lounges_Confirm\rest-service-config.csv|card\apis\bidvest\Bidvest_Lounge_API\POST_Lounges_Confirm\POST_Lounges_Confirm_context_path_Value_mappings.csv|

        Then "POSTLoungesConfirm" "status_code" "http_response" field or column should be populated with the value "eq" "201"

        Then data from "POSTLoungesConfirm" "json_response" should be returned as per expected results from "card\apis\bidvest\Bidvest_Lounge_API\POST_Lounges_Confirm\201_POST_Lounges_Confirm_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "card\apis\bidvest\Bidvest_Lounge_API\POST_Lounges_Confirm\201_POST_Lounges_Confirm_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|POST_Lounges_Confirm_201_Created__Confirmation_Was_Successful_Test_Case| |

    
@Default_Error_Processing_Request._POST_Lounges_Confirm_Bidvest_Lounge_API_Lounges_Confirm_Testing_Scenario
@allure.label.subSuite:Default_Error_Processing_Request._POST_Lounges_Confirm_Bidvest_Lounge_API_Lounges_Confirm_Testing_Scenario
    Scenario Outline: Default Error Processing Request. POST Lounges Confirm Bidvest Lounge API Lounges Confirm Testing Scenario
        Given I have started "Default Error Processing Request. POST Lounges Confirm Bidvest Lounge API Lounges Confirm Testing Scenario" test case number "<TestCaseId_and_TestDataRowIndex>" - "<TestCaseDescription>"
        And I have test data for "POSTLoungesConfirm" from "card\apis\bidvest\Bidvest_Lounge_API\POST_Lounges_Confirm\Default_POST_Lounges_Confirm_test_data.csv" loaded

        When I have called "POSTLoungesConfirm" REST API service using configuration and information from a data table
        			|Service_To_Call_Id|Service_Configuration_Csv_Path|service_contextPath_param_field_mappings_file_path|
			|POSTLoungesConfirm|card\apis\bidvest\Bidvest_Lounge_API\POST_Lounges_Confirm\rest-service-config.csv|card\apis\bidvest\Bidvest_Lounge_API\POST_Lounges_Confirm\POST_Lounges_Confirm_context_path_Value_mappings.csv|

        Then "POSTLoungesConfirm" "status_code" "http_response" field or column should be populated with the value "eq" "default"

        Then data from "POSTLoungesConfirm" "json_response" should be returned as per expected results from "card\apis\bidvest\Bidvest_Lounge_API\POST_Lounges_Confirm\Default_POST_Lounges_Confirm_test_data_expected_results.csv" csv data sheet, based on field mappings csv file "card\apis\bidvest\Bidvest_Lounge_API\POST_Lounges_Confirm\Default_POST_Lounges_Confirm_response_field_Mappings.csv", test source csv column name "data_target_field_name" and control source csv column name "data_source_field_name", with fields to exclude "<fields_to_exclude>"

        Examples:
           			|TestCaseId_and_TestDataRowIndex|TestCaseDescription|fields_to_exclude|
			|1|POST_Lounges_Confirm_Default_Error_Processing_Request__Test_Case| |

